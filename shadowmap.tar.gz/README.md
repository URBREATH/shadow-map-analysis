# shadowmap

> Part of the [VC Map Project](https://github.com/virtualcitySYSTEMS/map-ui)
> describe your plugin

Mathematical Precision: Uses solar declination and hour angle calculations based on day of year and latitude
Polar Region Handling: Properly handles polar day/night scenarios (midnight sun, polar night)
Time Zone Accuracy: Calculates times in UTC and accounts for longitude-based solar noon

/ Key astronomical calculations:

- Solar declination = 23.45° _ sin(360° _ (284 + dayOfYear) / 365°)
- Hour angle = arccos(-tan(latitude) \* tan(declination))
- Solar noon = 12h - (longitude / 15°)
- Sunrise = Solar noon - Hour angle (in hours)
- Sunset = Solar noon + Hour angle (in hours)

Praktische Abschätzung
Für eine grobe Berechnung der Lufttemperaturerhöhung in windstillen Bedingungen (ohne Verdunstung):
Beispiel: Asphaltfläche (100 m^2 ) mit Solarstrahlung 800 W/m^2, Absorptionskoeffizient 0.95, Luftvolumen 1000 m^3 (≈ Luftschicht von 10 m Höhe).
Energieaufnahme pro Stunde:Q=0.95⋅800⋅100⋅3600=2.736×10^8 J
Temperaturanstieg der Luft spezifische Wärmekapazität c = 1005 J/(kg·K) , Dichte rho = 1.2 , kg/m^3
ΔT=Q/(ρ⋅V⋅c)=(2.736×10^8)/(1.2⋅1000⋅1005)≈0.23 "°C"
